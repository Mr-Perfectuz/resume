<template>
  <!-- kontent boshlandi -->
  <div class="col-12 col-md-10 mt-4 mt-md-0">
    <h1>O'tkan kunlar </h1>

    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean aliquam bibendum ipsum, vel fringilla enim pharetra vitae. Pellentesque consectetur ornare est, vel ultrices dolor ornare sit amet. Cras commodo ornare consectetur. Etiam nec venenatis neque. Morbi efficitur diam eget tempor cursus. Nullam eget ex ante. Aliquam id sollicitudin ligula.
    </p>
    <p>
      Morbi a lorem vitae turpis iaculis pretium. Integer non orci nec dui vestibulum pharetra. Nulla facilisi. Donec accumsan est ex, a eleifend nulla facilisis tempus. Maecenas vel turpis viverra, pharetra metus at, luctus nunc. Nulla dictum accumsan ante. Cras nisi elit, blandit quis ullamcorper sed, bibendum at ante. Maecenas vitae tempus diam, sit amet feugiat erat. Sed pharetra, nulla ac euismod lobortis, sem ex rhoncus lacus, in venenatis tellus est sit amet lacus. Maecenas rhoncus vel ante eu fermentum. Ut libero ligula, porttitor at tellus a, feugiat viverra eros. Nunc pulvinar ipsum a augue placerat sollicitudin. Nam condimentum vestibulum elit. Nam finibus, nisl sit amet ultrices imperdiet, arcu felis vestibulum ipsum, quis mollis purus est vel sem.
    </p>
    <p>
      Proin mollis quis risus id imperdiet. Nullam viverra ipsum in dui consequat aliquam. Nulla a dui mattis, scelerisque nisi et, bibendum mauris. Duis condimentum turpis nec metus tincidunt auctor. Etiam ligula lorem, iaculis nec nulla et, vestibulum vestibulum odio. Nam bibendum nunc in sapien ultrices elementum. Vestibulum nisl ex, molestie at urna at, ultrices varius orci. Etiam vulputate tellus ex, ac egestas ante maximus quis. Donec egestas est sit amet ullamcorper dictum. Fusce cursus turpis a massa tincidunt, id pulvinar mi sagittis. Nulla id odio tellus. In quis ex feugiat nunc vulputate auctor vel vitae risus. Maecenas a ante aliquet, facilisis ante ut, accumsan orci.
    </p>

    <p>
      Duis vitae sollicitudin orci. Suspendisse vestibulum sollicitudin leo quis efficitur. Cras sit amet porttitor nibh. Integer cursus cursus ipsum ut accumsan. Vivamus interdum eros ac elit efficitur, in egestas elit viverra. Cras bibendum justo quis blandit imperdiet. Etiam eu neque erat.
    </p>

    <p>
      Nullam tempus nisl et elit dignissim hendrerit. Aenean fermentum, nulla vel efficitur finibus, urna elit lobortis mauris, sed iaculis turpis urna vel purus. Cras consectetur quam arcu, et consequat leo posuere ut. Nulla facilisi. Etiam pulvinar sagittis velit in gravida. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec convallis bibendum commodo. Donec ac orci quis lorem tempor sodales. Aenean vitae malesuada lacus, a auctor sem. Donec id posuere eros, non convallis risus. Phasellus neque mauris, elementum vitae volutpat nec, faucibus et diam. Nunc auctor mi nec lacus rutrum, a sodales erat faucibus
    </p>

    <p>
      Donec in egestas est. Suspendisse iaculis tempus tincidunt. Phasellus dignissim vel odio vel faucibus. Vestibulum mattis sed nulla non eleifend. Quisque ac felis sed libero vehicula aliquet. Nullam ac tortor eu nisl ultrices faucibus eget ac sapien. Sed scelerisque, orci a euismod gravida, arcu augue rhoncus ante, eu ultricies elit neque nec magna. Donec aliquam massa sagittis massa suscipit tempor. In ut elit et mi tincidunt efficitur. Curabitur imperdiet massa nunc, et molestie orci suscipit vel. Cras bibendum ornare neque a bibendum. Maecenas vel quam id sapien vulputate tristique sed vitae nibh. Mauris quis ante tincidunt, suscipit mauris id, vehicula turpis. Integer euismod leo a gravida volutpat. Cras ultrices, quam finibus ornare imperdiet, neque tortor iaculis lorem, eu cursus dui quam ac ex.
    </p>

  </div>
  <!-- kontent tugadi -->
</template>

<script>
export default {
  name: "BookinfoPage"
}
</script>

<style scoped>

</style>