<template>
  <div class="row">
    <div class="col">
      <footer class="bg-dark text-light p-5 mt-4">
        &copy; All rights reserved
      </footer>
    </div>
  </div>
</template>

<script>
export default {
  name: "FooterRow"
}
</script>

<style scoped>

</style>