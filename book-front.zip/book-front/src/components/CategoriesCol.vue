<template>
  <!-- category boshlandi -->
  <div class="col-12 col-md-2">
    <div class="list-group">
      <a href="#" class="list-group-item list-group-item-action">Detektiv</a>
      <a href="#" class="list-group-item list-group-item-action active" aria-current="true">Klassika</a>
      <a href="#" class="list-group-item list-group-item-action">Komediya</a>
      <a href="#" class="list-group-item list-group-item-action">Romantika</a>
      <a href="#" class="list-group-item list-group-item-action">Fantastika</a>
    </div>
  </div>
</template>

<script>
export default {
  name: "categoriesCol"
}
</script>

<style scoped>

</style>