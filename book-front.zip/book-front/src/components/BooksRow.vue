<template>
  <div class="row">

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <router-link href="book.html" class="btn btn-primary">O'qish</router-link>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <a href="book.html" class="btn btn-primary">O'qish</a>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <a href="book.html" class="btn btn-primary">O'qish</a>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <a href="book.html" class="btn btn-primary">O'qish</a>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <a href="book.html" class="btn btn-primary">O'qish</a>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

    <!-- kitob boshlandi -->
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-4">
      <div class="card">
        <img src="img/otkan-kunlar.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">O'tkan kunlar</h5>
          <p class="card-text">Otabek va ikki qiz, yohud sevgi uchburchagi...</p>
          <a href="book.html" class="btn btn-primary">O'qish</a>
        </div>
      </div>
    </div>
    <!-- kitob tugadi -->

  </div>
</template>

<script>
export default {
  name: "booksRow"
}
</script>

<style scoped>

</style>